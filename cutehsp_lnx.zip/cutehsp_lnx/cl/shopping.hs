	mes "買いたい品物は何ですか？"
	input s,64,2

	mes s+"はひとついくらですか？"
	input a,5,2

	mes s+"をいくつ買いますか？"
	input b,5,2

*pay
	mes "いくら払いますか？"
	input c,5,2

	a=int(a):b=int(b):c=int(c)	;変数を文字型から整数型へ変換

	d=c-a*b

	if d<0 {
		mes "お金が足りません。"
		goto *pay
	}

	mes "ありがとうございます。"

	if d=0 {
		mes "ちょうどいただきます。"
	} else {
		mes ""+d+"円のおつりです。"
	}

