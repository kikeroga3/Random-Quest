//
//	hsp3cnv(3.5b5) generated source
//	[run_scn.ax]
//
#include "hsp3r.h"

#define _HSP3CNV_DATE "2017/10/14"
#define _HSP3CNV_TIME "19:47:52"
#define _HSP3CNV_MAXVAR 24
#define _HSP3CNV_MAXHPI 16
#define _HSP3CNV_VERSION 0x350
#define _HSP3CNV_BOOTOPT 12288

/*-----------------------------------------------------------*/

static PVal *Var_0;
static PVal *Var_1;
static PVal *Var_2;
static PVal *Var_3;
static PVal *Var_4;
static PVal *Var_5;
static PVal *Var_6;
static PVal *Var_7;
static PVal *Var_8;
static PVal *Var_9;
static PVal *Var_10;
static PVal *Var_11;
static PVal *Var_12;
static PVal *Var_13;
static PVal *Var_14;
static PVal *Var_15;
static PVal *Var_16;
static PVal *Var_17;
static PVal *Var_18;
static PVal *Var_19;
static PVal *Var_20;
static PVal *Var_21;
static PVal *Var_22;
static PVal *Var_23;

/*-----------------------------------------------------------*/

void __HspEntry( void ) {
	// Var initalize
	Var_0 = &mem_var[0];
	Var_1 = &mem_var[1];
	Var_2 = &mem_var[2];
	Var_3 = &mem_var[3];
	Var_4 = &mem_var[4];
	Var_5 = &mem_var[5];
	Var_6 = &mem_var[6];
	Var_7 = &mem_var[7];
	Var_8 = &mem_var[8];
	Var_9 = &mem_var[9];
	Var_10 = &mem_var[10];
	Var_11 = &mem_var[11];
	Var_12 = &mem_var[12];
	Var_13 = &mem_var[13];
	Var_14 = &mem_var[14];
	Var_15 = &mem_var[15];
	Var_16 = &mem_var[16];
	Var_17 = &mem_var[17];
	Var_18 = &mem_var[18];
	Var_19 = &mem_var[19];
	Var_20 = &mem_var[20];
	Var_21 = &mem_var[21];
	Var_22 = &mem_var[22];
	Var_23 = &mem_var[23];

	// celload "key.png", 1
	PushInt(1); 
	PushStr("key.png"); 
	Extcmd(60,2);
	// font "ＭＳ ゴシック", 12, 0
	PushInt(0); 
	PushInt(12); 
	PushStr("ＭＳ ゴシック"); 
	Extcmd(20,3);
	// sdim _HspVar0, 40, 120
	PushInt(120); 
	PushInt(40); 
	PushVAP(Var_0,0); 
	Prgcmd(10,3);
	// sdim _HspVar1, 64
	PushInt(64); 
	PushVAP(Var_1,0); 
	Prgcmd(10,2);
	// sdim _HspVar2, 5000
	PushInt(5000); 
	PushVAP(Var_2,0); 
	Prgcmd(10,2);
	// sdim _HspVar3, 65500
	PushInt(65500); 
	PushVAP(Var_3,0); 
	Prgcmd(10,2);
	// dim _HspVar4, 16
	PushInt(16); 
	PushVAP(Var_4,0); 
	Prgcmd(9,2);
	// dim _HspVar5, 256
	PushInt(256); 
	PushVAP(Var_5,0); 
	Prgcmd(9,2);
	// sdim _HspVar6, 5300
	PushInt(5300); 
	PushVAP(Var_6,0); 
	Prgcmd(10,2);
	// _HspVar1 ="open.scn"
	PushStr("open.scn"); 
	VarSet(Var_1,0);
	TaskSwitch(0);
}

static void L0000( void ) {
	// gosub
	PushLabel(1); 
	PushLabel(27); Prgcmd(1,2); return;
}

static void L0027( void ) {
	// _HspVar7 =0
	PushInt(0); 
	VarSet(Var_7,0);
	// _HspVar8 =_HspVar7
	PushVar(Var_7,0); 
	VarSet(Var_8,0);
	// _HspVar9 =0
	PushInt(0); 
	VarSet(Var_9,0);
	TaskSwitch(2);
}

static void L0002( void ) {
	// _HspVar10 =peek(_HspVar3, _HspVar7)
	PushFuncEnd(); 	PushVAP(Var_7,0); 
	PushVAP(Var_3,0); 
PushIntfunc(9,2); 
	VarSet(Var_10,0);
	// if _HspVar10>9
	PushVar(Var_10,0); PushInt(9); CalcGtI(); 
	if (HspIf()) { TaskSwitch(28); return; }
	// if _HspVar10<14
	PushVar(Var_10,0); PushInt(14); CalcLtI(); 
	if (HspIf()) { TaskSwitch(29); return; }
	// _HspVar7 =_HspVar7+1
	PushVar(Var_7,0); PushInt(1); CalcAddI(); 
	VarSet(Var_7,0);
	// goto *L0002
	TaskSwitch(2);
	return;
	TaskSwitch(29);
}

static void L0029( void ) {
	// repeat
	PushLabel(3); 
	PushLabel(30); Prgcmd(4,2); return;
	TaskSwitch(30);
}

static void L0030( void ) {
	// _HspVar11 =peek(_HspVar3, _HspVar7)
	PushFuncEnd(); 	PushVAP(Var_7,0); 
	PushVAP(Var_3,0); 
PushIntfunc(9,2); 
	VarSet(Var_11,0);
	// if _HspVar11<10
	PushVar(Var_11,0); PushInt(10); CalcLtI(); 
	if (HspIf()) { TaskSwitch(31); return; }
	// _HspVar11 =0
	PushInt(0); 
	VarSet(Var_11,0);
	// _HspVar7 =_HspVar7-1
	PushVar(Var_7,0); PushInt(1); CalcSubI(); 
	VarSet(Var_7,0);
	TaskSwitch(31);
}

static void L0031( void ) {
	// poke _HspVar2, cnt, _HspVar11
	PushVAP(Var_11,0); 
	PushSysvar(4,0); 
	PushVAP(Var_2,0); 
	Intcmd(26,3);
	// _HspVar7 =_HspVar7+1
	PushVar(Var_7,0); PushInt(1); CalcAddI(); 
	VarSet(Var_7,0);
	// if _HspVar11=0
	PushVar(Var_11,0); PushInt(0); CalcEqI(); 
	if (HspIf()) { TaskSwitch(32); return; }
	// break *L0003
	PushLabel(3); 
	Prgcmd(3,1);
	return;
	TaskSwitch(32);
}

static void L0032( void ) {
	// loop 
	Prgcmd(5,0);
	return;
	TaskSwitch(3);
}

static void L0003( void ) {
	// gosub
	PushLabel(4); 
	PushLabel(33); Prgcmd(1,2); return;
}

static void L0033( void ) {
	TaskSwitch(34);
}

static void L0028( void ) {
	// else
	// if _HspVar10=1
	PushVar(Var_10,0); PushInt(1); CalcEqI(); 
	if (HspIf()) { TaskSwitch(35); return; }
	// end 
	Prgcmd(16,0);
	return;
	TaskSwitch(35);
}

static void L0035( void ) {
	// if _HspVar10=2
	PushVar(Var_10,0); PushInt(2); CalcEqI(); 
	if (HspIf()) { TaskSwitch(36); return; }
	// _HspVar7 =_HspVar7+1
	PushVar(Var_7,0); PushInt(1); CalcAddI(); 
	VarSet(Var_7,0);
	// gosub
	PushLabel(5); 
	PushLabel(37); Prgcmd(1,2); return;
}

static void L0037( void ) {
	TaskSwitch(36);
}

static void L0036( void ) {
	// if _HspVar10=3
	PushVar(Var_10,0); PushInt(3); CalcEqI(); 
	if (HspIf()) { TaskSwitch(38); return; }
	// _HspVar7 =_HspVar8
	PushVar(Var_8,0); 
	VarSet(Var_7,0);
	TaskSwitch(38);
}

static void L0038( void ) {
	// if _HspVar10=4
	PushVar(Var_10,0); PushInt(4); CalcEqI(); 
	if (HspIf()) { TaskSwitch(39); return; }
	// _HspVar4 (_HspVar9)=peek(_HspVar3, _HspVar7+1)
	PushFuncEnd(); 	PushVar(Var_7,0); PushInt(1); CalcAddI(); 
	PushVAP(Var_3,0); 
PushIntfunc(9,2); 
	PushVar(Var_9,0); 
	VarSet(Var_4,1);
	// _HspVar9 =_HspVar9+1
	PushVar(Var_9,0); PushInt(1); CalcAddI(); 
	VarSet(Var_9,0);
	// _HspVar7 =_HspVar7+2
	PushVar(Var_7,0); PushInt(2); CalcAddI(); 
	VarSet(Var_7,0);
	TaskSwitch(39);
}

static void L0039( void ) {
	// if _HspVar10=5
	PushVar(Var_10,0); PushInt(5); CalcEqI(); 
	if (HspIf()) { TaskSwitch(40); return; }
	// _HspVar12 =peek(_HspVar3, _HspVar7+1)
	PushFuncEnd(); 	PushVar(Var_7,0); PushInt(1); CalcAddI(); 
	PushVAP(Var_3,0); 
PushIntfunc(9,2); 
	VarSet(Var_12,0);
	// _HspVar7 =_HspVar7+2
	PushVar(Var_7,0); PushInt(2); CalcAddI(); 
	VarSet(Var_7,0);
	// _HspVar8 =_HspVar7
	PushVar(Var_7,0); 
	VarSet(Var_8,0);
	// gosub
	PushLabel(6); 
	PushLabel(41); Prgcmd(1,2); return;
}

static void L0041( void ) {
	TaskSwitch(40);
}

static void L0040( void ) {
	// if _HspVar10=6
	PushVar(Var_10,0); PushInt(6); CalcEqI(); 
	if (HspIf()) { TaskSwitch(42); return; }
	// _HspVar11 =peek(_HspVar3, _HspVar7+1)-1
	PushFuncEnd(); 	PushVar(Var_7,0); PushInt(1); CalcAddI(); 
	PushVAP(Var_3,0); 
PushIntfunc(9,2); PushInt(1); CalcSubI(); 
	VarSet(Var_11,0);
	// _HspVar13 =peek(_HspVar3, _HspVar7+2)-1
	PushFuncEnd(); 	PushVar(Var_7,0); PushInt(2); CalcAddI(); 
	PushVAP(Var_3,0); 
PushIntfunc(9,2); PushInt(1); CalcSubI(); 
	VarSet(Var_13,0);
	// _HspVar7 =_HspVar7+3
	PushVar(Var_7,0); PushInt(3); CalcAddI(); 
	VarSet(Var_7,0);
	// if _HspVar13>30
	PushVar(Var_13,0); PushInt(30); CalcGtI(); 
	if (HspIf()) { TaskSwitch(43); return; }
	// _HspVar5 (_HspVar11)=rnd(_HspVar13-30)
	PushFuncEnd(); 	PushVar(Var_13,0); PushInt(30); CalcSubI(); 
PushIntfunc(1,1); 
	PushVar(Var_11,0); 
	VarSet(Var_5,1);
	TaskSwitch(43);
}

static void L0043( void ) {
	// if (_HspVar13>20_HspVar13<31)&
	PushVar(Var_13,0); PushInt(20); CalcGtI(); PushVar(Var_13,0); PushInt(31); CalcLtI(); CalcAndI(); 
	if (HspIf()) { TaskSwitch(44); return; }
	// _HspVar5 (_HspVar11)=_HspVar13-20-_HspVar5(_HspVar11)
		PushVar(Var_11,0); 
PushVar(Var_5,1); PushVar(Var_13,0); PushInt(20); CalcSubI(); CalcSubI(); 
	PushVar(Var_11,0); 
	VarSet(Var_5,1);
	TaskSwitch(44);
}

static void L0044( void ) {
	// if (_HspVar13>10_HspVar13<21)&
	PushVar(Var_13,0); PushInt(10); CalcGtI(); PushVar(Var_13,0); PushInt(21); CalcLtI(); CalcAndI(); 
	if (HspIf()) { TaskSwitch(45); return; }
	// _HspVar5 (_HspVar11)=_HspVar13-10+_HspVar5(_HspVar11)
		PushVar(Var_11,0); 
PushVar(Var_5,1); PushVar(Var_13,0); PushInt(10); CalcSubI(); CalcAddI(); 
	PushVar(Var_11,0); 
	VarSet(Var_5,1);
	TaskSwitch(45);
}

static void L0045( void ) {
	// if _HspVar13<11
	PushVar(Var_13,0); PushInt(11); CalcLtI(); 
	if (HspIf()) { TaskSwitch(46); return; }
	// _HspVar5 (_HspVar11)=_HspVar13
	PushVar(Var_13,0); 
	PushVar(Var_11,0); 
	VarSet(Var_5,1);
	TaskSwitch(46);
}

static void L0046( void ) {
	TaskSwitch(42);
}

static void L0042( void ) {
	// if _HspVar5(_HspVar11)<0
		PushVar(Var_11,0); 
	PushVar(Var_5,1); PushInt(0); CalcLtI(); 
	if (HspIf()) { TaskSwitch(47); return; }
	// _HspVar5 (_HspVar11)=0
	PushInt(0); 
	PushVar(Var_11,0); 
	VarSet(Var_5,1);
	TaskSwitch(47);
}

static void L0047( void ) {
	// if _HspVar5(_HspVar11)>254
		PushVar(Var_11,0); 
	PushVar(Var_5,1); PushInt(254); CalcGtI(); 
	if (HspIf()) { TaskSwitch(48); return; }
	// _HspVar5 (_HspVar11)=254
	PushInt(254); 
	PushVar(Var_11,0); 
	VarSet(Var_5,1);
	TaskSwitch(48);
}

static void L0048( void ) {
	// if _HspVar10=7
	PushVar(Var_10,0); PushInt(7); CalcEqI(); 
	if (HspIf()) { TaskSwitch(49); return; }
	// _HspVar11 =peek(_HspVar3, _HspVar7+1)-1
	PushFuncEnd(); 	PushVar(Var_7,0); PushInt(1); CalcAddI(); 
	PushVAP(Var_3,0); 
PushIntfunc(9,2); PushInt(1); CalcSubI(); 
	VarSet(Var_11,0);
	// _HspVar13 =peek(_HspVar3, _HspVar7+2)-1
	PushFuncEnd(); 	PushVar(Var_7,0); PushInt(2); CalcAddI(); 
	PushVAP(Var_3,0); 
PushIntfunc(9,2); PushInt(1); CalcSubI(); 
	VarSet(Var_13,0);
	// _HspVar12 =peek(_HspVar3, _HspVar7+3)
	PushFuncEnd(); 	PushVar(Var_7,0); PushInt(3); CalcAddI(); 
	PushVAP(Var_3,0); 
PushIntfunc(9,2); 
	VarSet(Var_12,0);
	// _HspVar7 =_HspVar7+4
	PushVar(Var_7,0); PushInt(4); CalcAddI(); 
	VarSet(Var_7,0);
	// if _HspVar5(_HspVar11)=_HspVar13
		PushVar(Var_11,0); 
	PushVar(Var_5,1); PushVar(Var_13,0); CalcEqI(); 
	if (HspIf()) { TaskSwitch(50); return; }
	// _HspVar8 =_HspVar7
	PushVar(Var_7,0); 
	VarSet(Var_8,0);
	// gosub
	PushLabel(6); 
	PushLabel(51); Prgcmd(1,2); return;
}

static void L0051( void ) {
	TaskSwitch(50);
}

static void L0050( void ) {
	TaskSwitch(49);
}

static void L0049( void ) {
	// if _HspVar10=8
	PushVar(Var_10,0); PushInt(8); CalcEqI(); 
	if (HspIf()) { TaskSwitch(52); return; }
	// _HspVar14 =_HspVar7+1
	PushVar(Var_7,0); PushInt(1); CalcAddI(); 
	VarSet(Var_14,0);
	// getstr _HspVar1, _HspVar3, _HspVar14
	PushVAP(Var_14,0); 
	PushVAP(Var_3,0); 
	PushVAP(Var_1,0); 
	Intcmd(29,3);
	// goto *L0000
	TaskSwitch(0);
	return;
	TaskSwitch(52);
}

static void L0052( void ) {
	// if _HspVar10=9
	PushVar(Var_10,0); PushInt(9); CalcEqI(); 
	if (HspIf()) { TaskSwitch(53); return; }
	// _HspVar7 =_HspVar7+2
	PushVar(Var_7,0); PushInt(2); CalcAddI(); 
	VarSet(Var_7,0);
	TaskSwitch(53);
}

static void L0053( void ) {
	TaskSwitch(34);
}

static void L0034( void ) {
	// goto *L0002
	TaskSwitch(2);
	return;
	TaskSwitch(1);
}

static void L0001( void ) {
	// bload _HspVar1, _HspVar3
	PushVAP(Var_3,0); 
	PushVAP(Var_1,0); 
	Intcmd(22,2);
	// _HspVar15 =strsize
	PushSysvar(6,0); 
	VarSet(Var_15,0);
	// repeat
	PushVAP(Var_15,0); 
	PushLabel(7); 
	PushLabel(54); Prgcmd(4,3); return;
	TaskSwitch(54);
}

static void L0054( void ) {
	// _HspVar11 =peek(_HspVar3, cnt)
	PushFuncEnd(); 	PushSysvar(4,0); 
	PushVAP(Var_3,0); 
PushIntfunc(9,2); 
	VarSet(Var_11,0);
	// if _HspVar11=0
	PushVar(Var_11,0); PushInt(0); CalcEqI(); 
	if (HspIf()) { TaskSwitch(55); return; }
	// _HspVar11 =255
	PushInt(255); 
	VarSet(Var_11,0);
	TaskSwitch(55);
}

static void L0055( void ) {
	// poke _HspVar3, cnt, 255-_HspVar11
	PushInt(255); PushVar(Var_11,0); CalcSubI(); 
	PushSysvar(4,0); 
	PushVAP(Var_3,0); 
	Intcmd(26,3);
	// loop 
	Prgcmd(5,0);
	return;
	TaskSwitch(7);
}

static void L0007( void ) {
	// return 
	Prgcmd(2,0);
	return;
	TaskSwitch(5);
}

static void L0005( void ) {
	// gosub
	PushLabel(8); 
	PushLabel(56); Prgcmd(1,2); return;
}

static void L0056( void ) {
	// if _HspVar11=12
	PushVar(Var_11,0); PushInt(12); CalcEqI(); 
	if (HspIf()) { TaskSwitch(57); return; }
	// _HspVar2 ="[Quit]"
	PushStr("[Quit]"); 
	VarSet(Var_2,0);
	// gosub
	PushLabel(4); 
	PushLabel(58); Prgcmd(1,2); return;
}

static void L0058( void ) {
	// wait 100
	PushInt(100); 
	Prgcmd(7,1);
	TaskSwitch(59);
}

static void L0059( void ) {
	// end 
	Prgcmd(16,0);
	return;
	TaskSwitch(57);
}

static void L0057( void ) {
	// if _HspVar11=11
	PushVar(Var_11,0); PushInt(11); CalcEqI(); 
	if (HspIf()) { TaskSwitch(60); return; }
	// gosub
	PushLabel(9); 
	PushLabel(61); Prgcmd(1,2); return;
}

static void L0061( void ) {
	// goto *L0005
	TaskSwitch(5);
	return;
	TaskSwitch(60);
}

static void L0060( void ) {
	// if _HspVar11=10
	PushVar(Var_11,0); PushInt(10); CalcEqI(); 
	if (HspIf()) { TaskSwitch(62); return; }
	// gosub
	PushLabel(10); 
	PushLabel(63); Prgcmd(1,2); return;
}

static void L0063( void ) {
	// goto *L0005
	TaskSwitch(5);
	return;
	TaskSwitch(62);
}

static void L0062( void ) {
	// if _HspVar9=0
	PushVar(Var_9,0); PushInt(0); CalcEqI(); 
	if (HspIf()) { TaskSwitch(64); return; }
	// _HspVar2 ="\n"
	PushStr("\r\n"); 
	VarSet(Var_2,0);
	// gosub
	PushLabel(4); 
	PushLabel(65); Prgcmd(1,2); return;
}

static void L0065( void ) {
	// return 
	Prgcmd(2,0);
	return;
	TaskSwitch(64);
}

static void L0064( void ) {
	// _HspVar8 =_HspVar7
	PushVar(Var_7,0); 
	VarSet(Var_8,0);
	// if (_HspVar11>_HspVar9_HspVar11<1)|
	PushVar(Var_11,0); PushVar(Var_9,0); CalcGtI(); PushVar(Var_11,0); PushInt(1); CalcLtI(); CalcOrI(); 
	if (HspIf()) { TaskSwitch(66); return; }
	// goto *L0005
	TaskSwitch(5);
	return;
	TaskSwitch(66);
}

static void L0066( void ) {
	// _HspVar2 =("["+_HspVar11)+"]\n"
	PushStr("["); PushVar(Var_11,0); CalcAddI(); PushStr("]\r\n"); CalcAddI(); 
	VarSet(Var_2,0);
	// gosub
	PushLabel(4); 
	PushLabel(67); Prgcmd(1,2); return;
}

static void L0067( void ) {
	// _HspVar12 =_HspVar4(_HspVar11-1)
		PushVar(Var_11,0); PushInt(1); CalcSubI(); 
PushVar(Var_4,1); 
	VarSet(Var_12,0);
	// gosub
	PushLabel(6); 
	PushLabel(68); Prgcmd(1,2); return;
}

static void L0068( void ) {
	// _HspVar9 =0
	PushInt(0); 
	VarSet(Var_9,0);
	// return 
	Prgcmd(2,0);
	return;
	TaskSwitch(6);
}

static void L0006( void ) {
	// _HspVar16 =0
	PushInt(0); 
	VarSet(Var_16,0);
	// repeat
	PushVAP(Var_15,0); 
	PushLabel(11); 
	PushLabel(69); Prgcmd(4,3); return;
	TaskSwitch(69);
}

static void L0069( void ) {
	// _HspVar14 =peek(_HspVar3, _HspVar16)
	PushFuncEnd(); 	PushVAP(Var_16,0); 
	PushVAP(Var_3,0); 
PushIntfunc(9,2); 
	VarSet(Var_14,0);
	// _HspVar17 =peek(_HspVar3, _HspVar16+1)
	PushFuncEnd(); 	PushVar(Var_16,0); PushInt(1); CalcAddI(); 
	PushVAP(Var_3,0); 
PushIntfunc(9,2); 
	VarSet(Var_17,0);
	// if (_HspVar14=9_HspVar17=_HspVar12)&
	PushVar(Var_14,0); PushInt(9); CalcEqI(); PushVar(Var_17,0); PushVar(Var_12,0); CalcEqI(); CalcAndI(); 
	if (HspIf()) { TaskSwitch(70); return; }
	// _HspVar7 =_HspVar16+2
	PushVar(Var_16,0); PushInt(2); CalcAddI(); 
	VarSet(Var_7,0);
	// break *L000b
	PushLabel(11); 
	Prgcmd(3,1);
	return;
	TaskSwitch(70);
}

static void L0070( void ) {
	// if ((((_HspVar14>9_HspVar14=1)|_HspVar14=2)|_HspVar14=3)|_HspVar14=8)|
	PushVar(Var_14,0); PushInt(9); CalcGtI(); PushVar(Var_14,0); PushInt(1); CalcEqI(); CalcOrI(); PushVar(Var_14,0); PushInt(2); CalcEqI(); CalcOrI(); PushVar(Var_14,0); PushInt(3); CalcEqI(); CalcOrI(); PushVar(Var_14,0); PushInt(8); CalcEqI(); CalcOrI(); 
	if (HspIf()) { TaskSwitch(71); return; }
	// _HspVar16 =_HspVar16+1
	PushVar(Var_16,0); PushInt(1); CalcAddI(); 
	VarSet(Var_16,0);
	TaskSwitch(71);
}

static void L0071( void ) {
	// if ((_HspVar14=4_HspVar14=5)|_HspVar14=9)|
	PushVar(Var_14,0); PushInt(4); CalcEqI(); PushVar(Var_14,0); PushInt(5); CalcEqI(); CalcOrI(); PushVar(Var_14,0); PushInt(9); CalcEqI(); CalcOrI(); 
	if (HspIf()) { TaskSwitch(72); return; }
	// _HspVar16 =_HspVar16+2
	PushVar(Var_16,0); PushInt(2); CalcAddI(); 
	VarSet(Var_16,0);
	TaskSwitch(72);
}

static void L0072( void ) {
	// if _HspVar14=6
	PushVar(Var_14,0); PushInt(6); CalcEqI(); 
	if (HspIf()) { TaskSwitch(73); return; }
	// _HspVar16 =_HspVar16+3
	PushVar(Var_16,0); PushInt(3); CalcAddI(); 
	VarSet(Var_16,0);
	TaskSwitch(73);
}

static void L0073( void ) {
	// if _HspVar14=7
	PushVar(Var_14,0); PushInt(7); CalcEqI(); 
	if (HspIf()) { TaskSwitch(74); return; }
	// _HspVar16 =_HspVar16+4
	PushVar(Var_16,0); PushInt(4); CalcAddI(); 
	VarSet(Var_16,0);
	TaskSwitch(74);
}

static void L0074( void ) {
	// if _HspVar16>_HspVar15
	PushVar(Var_16,0); PushVar(Var_15,0); CalcGtI(); 
	if (HspIf()) { TaskSwitch(75); return; }
	// break *L000b
	PushLabel(11); 
	Prgcmd(3,1);
	return;
	TaskSwitch(75);
}

static void L0075( void ) {
	// loop 
	Prgcmd(5,0);
	return;
	TaskSwitch(11);
}

static void L0011( void ) {
	// return 
	Prgcmd(2,0);
	return;
	TaskSwitch(10);
}

static void L0010( void ) {
	// repeat
	PushInt(5300); 
	PushLabel(12); 
	PushLabel(76); Prgcmd(4,3); return;
	TaskSwitch(76);
}

static void L0076( void ) {
	// poke _HspVar6, cnt, 255
	PushInt(255); 
	PushSysvar(4,0); 
	PushVAP(Var_6,0); 
	Intcmd(26,3);
	// loop 
	Prgcmd(5,0);
	return;
	TaskSwitch(12);
}

static void L0012( void ) {
	// repeat
	PushInt(16); 
	PushLabel(13); 
	PushLabel(77); Prgcmd(4,3); return;
	TaskSwitch(77);
}

static void L0077( void ) {
	// _HspVar11 =peek(_HspVar1, cnt)
	PushFuncEnd(); 	PushSysvar(4,0); 
	PushVAP(Var_1,0); 
PushIntfunc(9,2); 
	VarSet(Var_11,0);
	// if _HspVar11=0
	PushVar(Var_11,0); PushInt(0); CalcEqI(); 
	if (HspIf()) { TaskSwitch(78); return; }
	// break *L000d
	PushLabel(13); 
	Prgcmd(3,1);
	return;
	TaskSwitch(78);
}

static void L0078( void ) {
	// poke _HspVar6, cnt, _HspVar11
	PushVAP(Var_11,0); 
	PushSysvar(4,0); 
	PushVAP(Var_6,0); 
	Intcmd(26,3);
	// loop 
	Prgcmd(5,0);
	return;
	TaskSwitch(13);
}

static void L0013( void ) {
	// _HspVar14 =_HspVar7%128
	PushVar(Var_7,0); PushInt(128); CalcModI(); 
	VarSet(Var_14,0);
	// _HspVar17 =(_HspVar7/128)&127
	PushVar(Var_7,0); PushInt(128); CalcDivI(); PushInt(127); CalcAndI(); 
	VarSet(Var_17,0);
	// _HspVar18 =_HspVar7/16384
	PushVar(Var_7,0); PushInt(16384); CalcDivI(); 
	VarSet(Var_18,0);
	// poke _HspVar6, 16, _HspVar14+128
	PushVar(Var_14,0); PushInt(128); CalcAddI(); 
	PushInt(16); 
	PushVAP(Var_6,0); 
	Intcmd(26,3);
	// poke _HspVar6, 17, _HspVar17+128
	PushVar(Var_17,0); PushInt(128); CalcAddI(); 
	PushInt(17); 
	PushVAP(Var_6,0); 
	Intcmd(26,3);
	// poke _HspVar6, 18, _HspVar18+128
	PushVar(Var_18,0); PushInt(128); CalcAddI(); 
	PushInt(18); 
	PushVAP(Var_6,0); 
	Intcmd(26,3);
	// _HspVar14 =_HspVar8%128
	PushVar(Var_8,0); PushInt(128); CalcModI(); 
	VarSet(Var_14,0);
	// _HspVar17 =(_HspVar8/128)&127
	PushVar(Var_8,0); PushInt(128); CalcDivI(); PushInt(127); CalcAndI(); 
	VarSet(Var_17,0);
	// _HspVar18 =_HspVar8/16384
	PushVar(Var_8,0); PushInt(16384); CalcDivI(); 
	VarSet(Var_18,0);
	// poke _HspVar6, 19, _HspVar14+128
	PushVar(Var_14,0); PushInt(128); CalcAddI(); 
	PushInt(19); 
	PushVAP(Var_6,0); 
	Intcmd(26,3);
	// poke _HspVar6, 20, _HspVar17+128
	PushVar(Var_17,0); PushInt(128); CalcAddI(); 
	PushInt(20); 
	PushVAP(Var_6,0); 
	Intcmd(26,3);
	// poke _HspVar6, 21, _HspVar18+128
	PushVar(Var_18,0); PushInt(128); CalcAddI(); 
	PushInt(21); 
	PushVAP(Var_6,0); 
	Intcmd(26,3);
	// poke _HspVar6, 22, _HspVar9+1
	PushVar(Var_9,0); PushInt(1); CalcAddI(); 
	PushInt(22); 
	PushVAP(Var_6,0); 
	Intcmd(26,3);
	// repeat
	PushVAP(Var_9,0); 
	PushLabel(14); 
	PushLabel(79); Prgcmd(4,3); return;
	TaskSwitch(79);
}

static void L0079( void ) {
	// poke _HspVar6, 23+cnt, _HspVar4(cnt)
		PushSysvar(4,0); 
	PushVAP(Var_4,1); 
	PushInt(23); PushSysvar(4,0); CalcAddI(); 
	PushVAP(Var_6,0); 
	Intcmd(26,3);
	// loop 
	Prgcmd(5,0);
	return;
	TaskSwitch(14);
}

static void L0014( void ) {
	// repeat
	PushInt(250); 
	PushLabel(15); 
	PushLabel(80); Prgcmd(4,3); return;
	TaskSwitch(80);
}

static void L0080( void ) {
	// poke _HspVar6, 39+cnt, _HspVar5(cnt)+1
		PushSysvar(4,0); 
	PushVar(Var_5,1); PushInt(1); CalcAddI(); 
	PushInt(39); PushSysvar(4,0); CalcAddI(); 
	PushVAP(Var_6,0); 
	Intcmd(26,3);
	// loop 
	Prgcmd(5,0);
	return;
	TaskSwitch(15);
}

static void L0015( void ) {
	// repeat
	PushInt(5000); 
	PushLabel(16); 
	PushLabel(81); Prgcmd(4,3); return;
	TaskSwitch(81);
}

static void L0081( void ) {
	// _HspVar11 =peek(_HspVar2, cnt)
	PushFuncEnd(); 	PushSysvar(4,0); 
	PushVAP(Var_2,0); 
PushIntfunc(9,2); 
	VarSet(Var_11,0);
	// poke _HspVar6, 295+cnt, _HspVar11
	PushVAP(Var_11,0); 
	PushInt(295); PushSysvar(4,0); CalcAddI(); 
	PushVAP(Var_6,0); 
	Intcmd(26,3);
	// if _HspVar11=0
	PushVar(Var_11,0); PushInt(0); CalcEqI(); 
	if (HspIf()) { TaskSwitch(82); return; }
	// break *L0010
	PushLabel(16); 
	Prgcmd(3,1);
	return;
	TaskSwitch(82);
}

static void L0082( void ) {
	// loop 
	Prgcmd(5,0);
	return;
	TaskSwitch(16);
}

static void L0016( void ) {
	// bsave "save.dat", _HspVar6
	PushVAP(Var_6,0); 
	PushStr("save.dat"); 
	Intcmd(23,2);
	// _HspVar2 ="[Save]"
	PushStr("[Save]"); 
	VarSet(Var_2,0);
	// gosub
	PushLabel(4); 
	PushLabel(83); Prgcmd(1,2); return;
}

static void L0083( void ) {
	// return 
	Prgcmd(2,0);
	return;
	TaskSwitch(9);
}

static void L0009( void ) {
	// bload "save.dat", _HspVar6
	PushVAP(Var_6,0); 
	PushStr("save.dat"); 
	Intcmd(22,2);
	// repeat
	PushInt(16); 
	PushLabel(17); 
	PushLabel(84); Prgcmd(4,3); return;
	TaskSwitch(84);
}

static void L0084( void ) {
	// _HspVar11 =peek(_HspVar6, cnt)
	PushFuncEnd(); 	PushSysvar(4,0); 
	PushVAP(Var_6,0); 
PushIntfunc(9,2); 
	VarSet(Var_11,0);
	// if _HspVar11=255
	PushVar(Var_11,0); PushInt(255); CalcEqI(); 
	if (HspIf()) { TaskSwitch(85); return; }
	// _HspVar11 =0
	PushInt(0); 
	VarSet(Var_11,0);
	TaskSwitch(85);
}

static void L0085( void ) {
	// poke _HspVar1, cnt, _HspVar11
	PushVAP(Var_11,0); 
	PushSysvar(4,0); 
	PushVAP(Var_1,0); 
	Intcmd(26,3);
	// if _HspVar11=0
	PushVar(Var_11,0); PushInt(0); CalcEqI(); 
	if (HspIf()) { TaskSwitch(86); return; }
	// break *L0011
	PushLabel(17); 
	Prgcmd(3,1);
	return;
	TaskSwitch(86);
}

static void L0086( void ) {
	// loop 
	Prgcmd(5,0);
	return;
	TaskSwitch(17);
}

static void L0017( void ) {
	// gosub
	PushLabel(1); 
	PushLabel(87); Prgcmd(1,2); return;
}

static void L0087( void ) {
	// _HspVar14 =peek(_HspVar6, 16)-128
	PushFuncEnd(); 	PushInt(16); 
	PushVAP(Var_6,0); 
PushIntfunc(9,2); PushInt(128); CalcSubI(); 
	VarSet(Var_14,0);
	// _HspVar17 =peek(_HspVar6, 17)-128
	PushFuncEnd(); 	PushInt(17); 
	PushVAP(Var_6,0); 
PushIntfunc(9,2); PushInt(128); CalcSubI(); 
	VarSet(Var_17,0);
	// _HspVar18 =peek(_HspVar6, 18)-128
	PushFuncEnd(); 	PushInt(18); 
	PushVAP(Var_6,0); 
PushIntfunc(9,2); PushInt(128); CalcSubI(); 
	VarSet(Var_18,0);
	// _HspVar7 =((16384*_HspVar18128*_HspVar17)+)+_HspVar14
	PushInt(16384); PushVar(Var_18,0); CalcMulI(); PushInt(128); PushVar(Var_17,0); CalcMulI(); CalcAddI(); PushVar(Var_14,0); CalcAddI(); 
	VarSet(Var_7,0);
	// _HspVar14 =peek(_HspVar6, 19)-128
	PushFuncEnd(); 	PushInt(19); 
	PushVAP(Var_6,0); 
PushIntfunc(9,2); PushInt(128); CalcSubI(); 
	VarSet(Var_14,0);
	// _HspVar17 =peek(_HspVar6, 20)-128
	PushFuncEnd(); 	PushInt(20); 
	PushVAP(Var_6,0); 
PushIntfunc(9,2); PushInt(128); CalcSubI(); 
	VarSet(Var_17,0);
	// _HspVar18 =peek(_HspVar6, 21)-128
	PushFuncEnd(); 	PushInt(21); 
	PushVAP(Var_6,0); 
PushIntfunc(9,2); PushInt(128); CalcSubI(); 
	VarSet(Var_18,0);
	// _HspVar8 =((16384*_HspVar18128*_HspVar17)+)+_HspVar14
	PushInt(16384); PushVar(Var_18,0); CalcMulI(); PushInt(128); PushVar(Var_17,0); CalcMulI(); CalcAddI(); PushVar(Var_14,0); CalcAddI(); 
	VarSet(Var_8,0);
	// _HspVar9 =peek(_HspVar6, 22)-1
	PushFuncEnd(); 	PushInt(22); 
	PushVAP(Var_6,0); 
PushIntfunc(9,2); PushInt(1); CalcSubI(); 
	VarSet(Var_9,0);
	// repeat
	PushVAP(Var_9,0); 
	PushLabel(18); 
	PushLabel(88); Prgcmd(4,3); return;
	TaskSwitch(88);
}

static void L0088( void ) {
	// _HspVar4 (cnt)=peek(_HspVar6, 23+cnt)
	PushFuncEnd(); 	PushInt(23); PushSysvar(4,0); CalcAddI(); 
	PushVAP(Var_6,0); 
PushIntfunc(9,2); 
	PushSysvar(4,0); 
	VarSet(Var_4,1);
	// loop 
	Prgcmd(5,0);
	return;
	TaskSwitch(18);
}

static void L0018( void ) {
	// repeat
	PushInt(250); 
	PushLabel(19); 
	PushLabel(89); Prgcmd(4,3); return;
	TaskSwitch(89);
}

static void L0089( void ) {
	// _HspVar5 (cnt)=peek(_HspVar6, 39+cnt)-1
	PushFuncEnd(); 	PushInt(39); PushSysvar(4,0); CalcAddI(); 
	PushVAP(Var_6,0); 
PushIntfunc(9,2); PushInt(1); CalcSubI(); 
	PushSysvar(4,0); 
	VarSet(Var_5,1);
	// loop 
	Prgcmd(5,0);
	return;
	TaskSwitch(19);
}

static void L0019( void ) {
	// repeat
	PushInt(5000); 
	PushLabel(20); 
	PushLabel(90); Prgcmd(4,3); return;
	TaskSwitch(90);
}

static void L0090( void ) {
	// _HspVar11 =peek(_HspVar6, 295+cnt)
	PushFuncEnd(); 	PushInt(295); PushSysvar(4,0); CalcAddI(); 
	PushVAP(Var_6,0); 
PushIntfunc(9,2); 
	VarSet(Var_11,0);
	// poke _HspVar2, cnt, _HspVar11
	PushVAP(Var_11,0); 
	PushSysvar(4,0); 
	PushVAP(Var_2,0); 
	Intcmd(26,3);
	// if _HspVar11=0
	PushVar(Var_11,0); PushInt(0); CalcEqI(); 
	if (HspIf()) { TaskSwitch(91); return; }
	// break *L0014
	PushLabel(20); 
	Prgcmd(3,1);
	return;
	TaskSwitch(91);
}

static void L0091( void ) {
	// loop 
	Prgcmd(5,0);
	return;
	TaskSwitch(20);
}

static void L0020( void ) {
	// _HspVar2 ="[Load]\n"+_HspVar2
	PushStr("[Load]\r\n"); PushVar(Var_2,0); CalcAddI(); 
	VarSet(Var_2,0);
	// gosub
	PushLabel(4); 
	PushLabel(92); Prgcmd(1,2); return;
}

static void L0092( void ) {
	// return 
	Prgcmd(2,0);
	return;
	TaskSwitch(21);
}

static void L0021( void ) {
	// redraw 0
	PushInt(0); 
	Extcmd(27,1);
	// pos 0, 0
	PushInt(0); 
	PushInt(0); 
	Extcmd(17,2);
	// celput 1
	PushInt(1); 
	Extcmd(62,1);
	// color 255, 255, 255
	PushInt(255); 
	PushInt(255); 
	PushInt(255); 
	Extcmd(24,3);
	// repeat
	PushInt(23); 
	PushLabel(22); 
	PushLabel(93); Prgcmd(4,3); return;
	TaskSwitch(93);
}

static void L0093( void ) {
	// pos 0, 16*cnt
	PushInt(16); PushSysvar(4,0); CalcMulI(); 
	PushInt(0); 
	Extcmd(17,2);
	// mes _HspVar0(cnt)
		PushSysvar(4,0); 
	PushVAP(Var_0,1); 
	Extcmd(15,1);
	// loop 
	Prgcmd(5,0);
	return;
	TaskSwitch(22);
}

static void L0022( void ) {
	// redraw 1
	PushInt(1); 
	Extcmd(27,1);
	// return 
	Prgcmd(2,0);
	return;
	TaskSwitch(4);
}

static void L0004( void ) {
	// notesel _HspVar2
	PushVAP(Var_2,0); 
	Intcmd(34,1);
	// repeat
	PushFuncEnd(); 	PushInt(0); 
	PushIntfunc(14,1); 
	PushLabel(23); 
	PushLabel(94); Prgcmd(4,3); return;
	TaskSwitch(94);
}

static void L0094( void ) {
	// repeat
	PushInt(22); 
	PushLabel(24); 
	PushLabel(95); Prgcmd(4,3); return;
	TaskSwitch(95);
}

static void L0095( void ) {
	// _HspVar0 (cnt)=_HspVar0(cnt+1)
		PushSysvar(4,0); PushInt(1); CalcAddI(); 
PushVar(Var_0,1); 
	PushSysvar(4,0); 
	VarSet(Var_0,1);
	// loop 
	Prgcmd(5,0);
	return;
	TaskSwitch(24);
}

static void L0024( void ) {
	// noteget _HspVar0(22), cnt
	PushSysvar(4,0); 
		PushInt(22); 
	PushVAP(Var_0,1); 
	Intcmd(41,2);
	// gosub
	PushLabel(21); 
	PushLabel(96); Prgcmd(1,2); return;
}

static void L0096( void ) {
	// wait 1
	PushInt(1); 
	Prgcmd(7,1);
	TaskSwitch(97);
}

static void L0097( void ) {
	// loop 
	Prgcmd(5,0);
	return;
	TaskSwitch(23);
}

static void L0023( void ) {
	// return 
	Prgcmd(2,0);
	return;
	TaskSwitch(8);
}

static void L0008( void ) {
	// _HspVar19 =0
	PushInt(0); 
	VarSet(Var_19,0);
	// _HspVar20 =53
	PushInt(53); 
	VarSet(Var_20,0);
	// gosub
	PushLabel(21); 
	PushLabel(98); Prgcmd(1,2); return;
}

static void L0098( void ) {
	// repeat
	PushLabel(25); 
	PushLabel(99); Prgcmd(4,2); return;
	TaskSwitch(99);
}

static void L0099( void ) {
	// wait 1
	PushInt(1); 
	Prgcmd(7,1);
	TaskSwitch(100);
}

static void L0100( void ) {
	// getkey _HspVar21, 1
	PushInt(1); 
	PushVAP(Var_21,0); 
	Extcmd(35,2);
	// _HspVar22 =mousex/_HspVar20
	PushFuncEnd(); PushExtvar(0,0); PushVar(Var_20,0); CalcDivI(); 
	VarSet(Var_22,0);
	// _HspVar23 =mousey/_HspVar20
	PushFuncEnd(); PushExtvar(1,0); PushVar(Var_20,0); CalcDivI(); 
	VarSet(Var_23,0);
	// if (_HspVar21=0_HspVar19=1)&
	PushVar(Var_21,0); PushInt(0); CalcEqI(); PushVar(Var_19,0); PushInt(1); CalcEqI(); CalcAndI(); 
	if (HspIf()) { TaskSwitch(101); return; }
	// _HspVar11 =(8-_HspVar23*6+_HspVar22)+1
	PushVar(Var_22,0); PushInt(6); PushInt(8); PushVar(Var_23,0); CalcSubI(); CalcMulI(); CalcAddI(); PushInt(1); CalcAddI(); 
	VarSet(Var_11,0);
	// break *L0019
	PushLabel(25); 
	Prgcmd(3,1);
	return;
	TaskSwitch(101);
}

static void L0101( void ) {
	// _HspVar19 =_HspVar21
	PushVar(Var_21,0); 
	VarSet(Var_19,0);
	// loop 
	Prgcmd(5,0);
	return;
	TaskSwitch(25);
}

static void L0025( void ) {
	// return 
	Prgcmd(2,0);
	return;
	TaskSwitch(26);
}

static void L0026( void ) {
	// stop 
	Prgcmd(17,0);
	return;
	// goto 
	Prgcmd(0,0);
	return;
}

//-End of Source-------------------------------------------

CHSP3_TASK __HspTaskFunc[]={
(CHSP3_TASK) L0000,
(CHSP3_TASK) L0001,
(CHSP3_TASK) L0002,
(CHSP3_TASK) L0003,
(CHSP3_TASK) L0004,
(CHSP3_TASK) L0005,
(CHSP3_TASK) L0006,
(CHSP3_TASK) L0007,
(CHSP3_TASK) L0008,
(CHSP3_TASK) L0009,
(CHSP3_TASK) L0010,
(CHSP3_TASK) L0011,
(CHSP3_TASK) L0012,
(CHSP3_TASK) L0013,
(CHSP3_TASK) L0014,
(CHSP3_TASK) L0015,
(CHSP3_TASK) L0016,
(CHSP3_TASK) L0017,
(CHSP3_TASK) L0018,
(CHSP3_TASK) L0019,
(CHSP3_TASK) L0020,
(CHSP3_TASK) L0021,
(CHSP3_TASK) L0022,
(CHSP3_TASK) L0023,
(CHSP3_TASK) L0024,
(CHSP3_TASK) L0025,
(CHSP3_TASK) L0026,
(CHSP3_TASK) L0027,
(CHSP3_TASK) L0028,
(CHSP3_TASK) L0029,
(CHSP3_TASK) L0030,
(CHSP3_TASK) L0031,
(CHSP3_TASK) L0032,
(CHSP3_TASK) L0033,
(CHSP3_TASK) L0034,
(CHSP3_TASK) L0035,
(CHSP3_TASK) L0036,
(CHSP3_TASK) L0037,
(CHSP3_TASK) L0038,
(CHSP3_TASK) L0039,
(CHSP3_TASK) L0040,
(CHSP3_TASK) L0041,
(CHSP3_TASK) L0042,
(CHSP3_TASK) L0043,
(CHSP3_TASK) L0044,
(CHSP3_TASK) L0045,
(CHSP3_TASK) L0046,
(CHSP3_TASK) L0047,
(CHSP3_TASK) L0048,
(CHSP3_TASK) L0049,
(CHSP3_TASK) L0050,
(CHSP3_TASK) L0051,
(CHSP3_TASK) L0052,
(CHSP3_TASK) L0053,
(CHSP3_TASK) L0054,
(CHSP3_TASK) L0055,
(CHSP3_TASK) L0056,
(CHSP3_TASK) L0057,
(CHSP3_TASK) L0058,
(CHSP3_TASK) L0059,
(CHSP3_TASK) L0060,
(CHSP3_TASK) L0061,
(CHSP3_TASK) L0062,
(CHSP3_TASK) L0063,
(CHSP3_TASK) L0064,
(CHSP3_TASK) L0065,
(CHSP3_TASK) L0066,
(CHSP3_TASK) L0067,
(CHSP3_TASK) L0068,
(CHSP3_TASK) L0069,
(CHSP3_TASK) L0070,
(CHSP3_TASK) L0071,
(CHSP3_TASK) L0072,
(CHSP3_TASK) L0073,
(CHSP3_TASK) L0074,
(CHSP3_TASK) L0075,
(CHSP3_TASK) L0076,
(CHSP3_TASK) L0077,
(CHSP3_TASK) L0078,
(CHSP3_TASK) L0079,
(CHSP3_TASK) L0080,
(CHSP3_TASK) L0081,
(CHSP3_TASK) L0082,
(CHSP3_TASK) L0083,
(CHSP3_TASK) L0084,
(CHSP3_TASK) L0085,
(CHSP3_TASK) L0086,
(CHSP3_TASK) L0087,
(CHSP3_TASK) L0088,
(CHSP3_TASK) L0089,
(CHSP3_TASK) L0090,
(CHSP3_TASK) L0091,
(CHSP3_TASK) L0092,
(CHSP3_TASK) L0093,
(CHSP3_TASK) L0094,
(CHSP3_TASK) L0095,
(CHSP3_TASK) L0096,
(CHSP3_TASK) L0097,
(CHSP3_TASK) L0098,
(CHSP3_TASK) L0099,
(CHSP3_TASK) L0100,
(CHSP3_TASK) L0101,
(CHSP3_TASK) 0,

};

/*-----------------------------------------------------------*/


/*-----------------------------------------------------------*/

void __HspInit( Hsp3r *hsp3 ) {
	hsp3->Reset( _HSP3CNV_MAXVAR, _HSP3CNV_MAXHPI );
	hsp3->SetDataName( 0 );
	hsp3->SetFInfo( 0, 0 );
	hsp3->SetLInfo( 0, 0 );
	hsp3->SetMInfo( 0, 0 );
}

/*-----------------------------------------------------------*/

