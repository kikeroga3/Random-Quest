
	s1="abcdefg123456789HIJKLMNabcdefg"
	mes "Source Str.["+s1+"]"

	gosub *strlen:mes "strlen="+stat

	p1=5:p2=13
	gosub *strmid:mes "strmid="+refstr

	p1=103
	gosub *instr:mes "instr="+stat

	p2=3:p3=98
	gosub *getstr:mes "getstr="+refstr

	p1=rnd(30)-15
	gosub *sgn:mes "sgn("+p1+")="+stat

	v1=8.0
	gosub *sqrt:mes "sqrt("+v1+")="+refdval

	x1=0:y1=0:x2=10:y2=10
	v1=powf(x2-x1,2)+powf(y2-y1,2)
	gosub *sqrt:mes "dist("+x1+","+y1+")-("+x2+"," +y2+")="+refdval

	end

;Sub Functions

*strlen
	repeat
		if peek(s1,cnt)=0 :p1=cnt:break
	loop
	return p1

*strmid
	sdim s2,p2+1
	repeat p2
		poke s2,cnt,peek(s1,p1+cnt)
	loop
	return s2

*instr
	p3=-1
	repeat
		p2=peek(s1,cnt)
		if p2=p1 :p3=cnt:break
		if p2=0 :break
	loop
	return p3

*getstr
	gosub *strlen
	sdim s2,p1+1
	repeat p1
		p4=peek(s1,p2+cnt)
		if p4=p3 :poke s2,cnt,0:break
		poke s2,cnt,p4
	loop
	return s2

*sgn
	return (p1>0)-(p1<0)

*sqrt
	v2=v1/2.0:v3=0.0
	repeat
		if v2=v3 :break
		v3=v2:v2=(v2+v1/v2)/2.0
	loop
	return v2

