	sdim moj_bf,150
	bload "moj.bin",moj_bf

	;redraw 0
	color :boxf 0,0,640,480
	color 255,255,255
	moj_sz=3 :moj_x=30 :moj_y=30
	s1="THIS PROGRAM THAT DISPLAYS" :gosub *mojput
	s1="ALPHABETS AND NUMBERS" :gosub *mojput
	s1="WITH CUTEHSP" :gosub *mojput
	moj_y=moj_y+30
	s1="0123456789" :gosub *mojput
	s1="ABCDEFGHIJKLMNOPQRSTUVWXYZ" :gosub *mojput
	redraw 1

stop

*mojput
	p5=moj_x
	repeat
		p1=peek(s1,cnt) :if p1=0 :break
		if p1=32 :goto *spc
		if p1>64 :p1=p1-65 :else :p1=p1-48+26
		p2=p1*4
		p3=16777216*peek(moj_bf,p2)+65536*peek(moj_bf,p2+1)+256*peek(moj_bf,p2+2)+peek(moj_bf,p2+3)
		p4=16777216
		repeat 25
			if (p3&p4) {
				p_x=moj_x+moj_sz*(cnt\5)-(moj_sz*5/2)
				p_y=moj_y+moj_sz*(cnt/5)-(moj_sz*5/2)
				boxf p_x,p_y,p_x+moj_sz,p_y+moj_sz
			}
			p4=p4/2
		loop
*spc
		moj_x=moj_x+(moj_sz*5)+2
	loop
	moj_x=p5 :moj_y=moj_y+(moj_sz*5)+4
	return
