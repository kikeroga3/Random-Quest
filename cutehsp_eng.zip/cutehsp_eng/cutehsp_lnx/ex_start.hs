title "CuteHSP Extra"
font "tiny_en.ttf",48
pos 20,10:picload "tamarin.jpg"
pos 200,100:picload "cutehsp.png"
pos 35,360:mes "Hello, World!?"
mes "Display characters and images."
redraw 1
stop
