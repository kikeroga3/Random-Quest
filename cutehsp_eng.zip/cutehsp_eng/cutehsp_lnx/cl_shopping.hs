	mes "What is the item You want to buy?"
	input s,64,2

	mes "How much is "+s+"?"
	input a,5,2

	mes "How many are you going to buy "+s+"?"
	input b,5,2

*pay
	mes "How much will you pay?"
	input c,5,2

	a=int(a):b=int(b):c=int(c)

	d=c-a*b

	if d<0 {
		mes "Money is not enough."
		goto *pay
	}

	mes "Thank you very much."

	if d=0 {
		mes "You gave me the exact amount."
	} else {
		mes "Here's "+d+" yen in change."
	}

