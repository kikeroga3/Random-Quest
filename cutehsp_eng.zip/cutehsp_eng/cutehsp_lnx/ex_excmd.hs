; for cutehspx bload poke peek test program

	font "tiny.ttf",20

	sdim bf,512
	bf="0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ"
	mes bf

	a=peek(bf,11)
	mes "'B'=ASC("+a+")"

	poke bf,3,a
	mes bf

	poke bf,11,66+32
	mes bf

	bload "ex_excmd.hs",bf
	mes bf
	stop

