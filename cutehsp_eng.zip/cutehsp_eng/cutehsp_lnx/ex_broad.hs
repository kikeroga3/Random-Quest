	sdim bf,64000
	bload "chr2.bin",bf

	sz=5 :x=160 :y=300 :dy=0 :rs=9638 :sc=0

	repeat
		redraw 0

		color 160,0,0 :boxf 0,336,640,480
		color :boxf 0,0,640,336

		repeat 15 :rd(cnt)=rd(cnt+1) :loop
		gosub *prnd :rm=13+(sc/25) :rd(15)=(stat<rm)

		repeat 16
			if rd(cnt) :boxf 40*cnt,336,40*(cnt+1),400
		loop

		stick inp
		if (inp&272)>0 {
			if y=300 :dy=-30 :beep 1600,30
			dy=dy-8
		}
		y=y+dy :dy=dy+15
		if y>300 :y=300 :dy=0

		if rd(3) and y=300 :x=x-15 :y=360

		cno=cnt\2 :gosub *chrput

		if y=300 :beep 880,25

		title "Binary Road "+sc :sc=sc+1
		wait 15
		redraw 1

		if y=360 :break	
	loop

	beep 500,30
	stop

*prnd
	rs=(rs*5+14097)&65535
	return (rs/256)

*chrput
	xs=peek(bf,0) :m=xs*(xs/7) :cln=m*2+8 :adr=cno*cln

	repeat 3
		a=peek(bf,adr+1+cnt)&63
		r(cnt)=80*(a/16)+15 :g(cnt)=80*((a&12)/4)+15 :b(cnt)=80*(a&3)+15
	loop

	i=0
	repeat m
		c1=peek(bf,adr+4+cnt) :c2=peek(bf,adr+4+m+cnt)
		a=64
		repeat 7
			xx=x-(xs*sz/2)+(i\xs)*sz :yy=y-(xs*sz/2)+(i/xs)*sz
			c=((c1&a)>0)+2*((c2&a)>0)
			if c>0 {
				color r(c-1),g(c-1),b(c-1)
				boxf xx,yy,xx+sz-1,yy+sz-1
			}
			a=a/2 :i=i+1
		loop
	loop
	return
