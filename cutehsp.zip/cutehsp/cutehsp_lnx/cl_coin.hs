;Coin back and front
	co=rnd(2)
	mes "Coin is back(0) or front(1)?"
	input a,1,2
	if a=co {
		mes "Correct!"
	} else {
		mes "Incorrect.."
	}

