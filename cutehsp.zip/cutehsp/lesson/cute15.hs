a=101
if a=10 :title "a is 10."
stop
