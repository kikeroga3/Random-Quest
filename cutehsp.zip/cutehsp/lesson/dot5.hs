; 5x5 DOT WORK

	mx=10
	repeat mx
		ax(cnt)=rnd(640) :ay(cnt)=rnd(480)
		dx(cnt)=8*(rnd(3)-1) :dy(cnt)=8*(rnd(3)-1)
	loop

	repeat
		redraw 0
		color :boxf 0,0,640,480

		repeat mx
			ax(cnt)=ax(cnt)+dx(cnt)
			if ax(cnt)>639 or ax(cnt)<0 :dx(cnt)=-dx(cnt)
			ay(cnt)=ay(cnt)+dy(cnt)
			if ay(cnt)>479 or ay(cnt)<0 :dy(cnt)=-dy(cnt)

			px=ax(cnt) :py=ay(cnt)
			ch=1850169326 :gosub *dot5
		loop

		wait 3
		redraw 1
	loop
	stop

*dot5
	sz=8 :a=16777216 :c=ch/33554432
	p1=c/16 :p2=(c&12)/4 :p3=c&3
	color 80*p1+15,80*p2+15,80*p3+15
	repeat 25
		if (ch & a) {
			x=px+sz*(cnt\5)-(sz*5/2)
			y=py+sz*(cnt/5)-(sz*5/2)
			boxf x,y,x+sz,y+sz
		}
		a=a/2
	loop
	return
