x=320 :y=440 :by=-99
ey=500
sc=0

repeat
    redraw 0
    color 0,0,0 :boxf 0,0,639,479
    stick key

;自機移動
    if key=1 {
        x=x-8
        if x<0 :x=0
    }
    if key=4 {
        x=x+8
        if x>639 :x=639
    }
    gosub *own

;弾発射
    if key=16 and by<0 :bx=x :by=y
;弾移動
    if by>=0 {
        by=by-16
        color 250,200,0 :boxf bx-1,by-8,bx+1,by+8
    }

;敵発生
    if ey>480 {
        ex=rnd(640) :ey=-8
        dx=rnd(8)-4 :dy=rnd(8)+8
    }
;敵移動
    if ey<=480 {
        ex=ex+dx :ey=ey+dy :gosub *ufo
    }

    redraw 1

;当たり判定(敵と弾)
    if abs(ex-bx)<20 and abs(ey-by)<16 {
        by=-99 :ey=500
        sc=sc+1 :title "SCORE:"+sc
    }
;当たり判定(敵と自機)
    if abs(ex-x)<20 and abs(ey-y)<10 :break

    wait 5
loop
stop

;自機表示
*own
    color 0,100,250
    boxf x-16,y-5,x+16,y+10 :boxf x-6,y-15,x+6,y
    return

;敵表示
*ufo
    color 150,250,0 :boxf ex-20,ey-5,ex+20,ey+5:boxf ex-8,ey-10,ex+8,ey+10
    color 0,255,255 :boxf ex-2,ey-2,ex+2,ey+2
    return

