;Pseudo-random number

r=12345
repeat 30
	gosub *prnd
	title "Random Number="+stat
	wait 100
loop
stop

*prnd
	r=(r*5+14097)&65535
	return (r/256)

