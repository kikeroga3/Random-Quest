i=2:j=0
a(0)=10:a(2)=15:a(4)=30
s(0)="Emily":s(1)="Rachel":s(2)="Margaret"
title s(i)+" was "+a(j)+"."
stop
