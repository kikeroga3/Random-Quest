pset 10,10
stop
