a=3
b="Let's CuteHSP!"
title b+(a+8)
stop
