title "Rotation Control"

rd(0)=0
rd(1)=380188
rd(2)=703279
rd(3)=920751
rd(4)=999942
rd(5)=928960
rd(6)=718465
rd(7)=400069
rd(8)=21591
rd(9)=-360130
rd(10)=-687766
rd(11)=-912112
rd(12)=-999476
rd(13)=-936736
rd(14)=-733315
rd(15)=-419764
vct=0
repeat
	redraw 0
	color:boxf 0,0,639,479
	stick key
	if key=4 {
		vct=vct+1:if vct>15 :vct=0
	}
	if key=1 {
		vct=vct-1:if vct<0 :vct=15
	}
	x=rd(vct)/10000+320 :y=rd((vct+4)\16)/10000+240
	gosub *ufo
	wait 5
	redraw 1
loop

*ufo
    color 0,150,250:boxf x-20,y-5,x+20,y+5:boxf x-8,y-10,x+8,y+10
    color 255,255,255:boxf x-2,y-2,x+2,y+2
    return

