c=3
title "Calc "+c+"^ Result="+(c*c*c+c*c+c)
stop
