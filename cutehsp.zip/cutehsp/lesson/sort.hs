c=5
a(0)=15
a(1)=80
a(2)=43
a(3)=12
a(4)=38
title "Before Sorting="+a(0)+" "+a(1)+" "+a(2)+" "+a(3)+" "+a(4)
wait 500
repeat (c-1)
	repeat (c-1)
		if a(cnt)>a(cnt+1) {
			b=a(cnt):a(cnt)=a(cnt+1):a(cnt+1)=b
		}
	loop
loop
title "After Sorting="+a(0)+" "+a(1)+" "+a(2)+" "+a(3)+" "+a(4)
stop

