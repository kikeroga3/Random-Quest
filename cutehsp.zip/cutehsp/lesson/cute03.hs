pset 10,10
line 120,80,500,400
boxf 200,100,250,200
stop
