	fnm="act3.hs" :bsave "svdat",fnm

	fnm="park":gosub *grp
	mes "新宿公園の門番・安木。今ならヤツを倒せそうな気がするッ！"
	cm(0)="公園口へ":cm(1)="":cm(2)="":gosub *sel

	fnm="yasu":gosub *grp
	mes "「ほう…この気…！ 先ほどとは別人のようだ。面白い。"
	mes "　ならば、この安木！ 最大限の礼儀を以て応えてやろう」"
	cm(0)="見る":cm(1)="":cm(2)="":gosub *sel

	fnm="yasu2":gosub *grp
	mes "「ふはァ…はああァァ…！」"
	cm(0)="見る！":cm(1)="":cm(2)="":gosub *sel

	fnm="choya":gosub *grp
	mes "超安木・改"
	cm(0)="見る！？":cm(1)="":cm(2)="":gosub *sel

	fnm="choya2":gosub *grp
	mes "超安木・改「脆弱なる人間よ。恐れを知らぬ愚か者よ。"
	mes "　神の拳を…、天の罰を受けるがよい」"
	cm(0)="攻撃する":cm(1)="逃げる":cm(2)="":gosub *sel
	if stat!1 :goto *ggg

	fnm="pika":gosub *grp
	mes "「貧弱ッ！貧弱ゥッ！！」"
	mes "安木の超パワー『銀河ギリギリやっぱりお前がNo.1だ！』がさく裂！"
	mes "君は失神昏倒！"
	mes ""
	mes "GAME OVER"
	stop

*ggg
	gosub *grp
	mes "超安木・改「こそばゆいッ、こそばゆいわッ！ うわっはっはっは…！？"
	mes "　ぬっ、貴様は！」"
	cm(0)="振返る":cm(1)="":cm(2)="":gosub *sel

	fnm="ggg":gosub *grp
	mes "「よく頑張ったな！ 助太刀するぜ！ 立ち向かう勇気が大切なんだ！"
	mes "　いくぞ！ 友情パワーだ！」"
	cm(0)="パワー全開":cm(1)="":cm(2)="":gosub *sel

	fnm="pika":gosub *grp
	mes "その瞬間。超パワーが激突し、超新星の輝きが世界を包んだ。"
	cm(0)="気が遠くなる":cm(1)="":cm(2)="":gosub *sel

	fnm="way":gosub *grp
	mes "やがて気がついたとき、すでに日は落ち、周りには誰の姿もなかった。"
	mes "君は、ため息を一つ吐くと帰路につくのだった。"
	mes ""
	mes "So-so END"
	stop

*grp
	color 255,255,255:boxf 0,0,640,480
	color 0,0,0
	pos 10,10:picload fnm+".png"
	pos 10,320
	return

*sel
	pos 500,20
	repeat 3:mes cm(cnt):loop
	repeat
		wait 10 :stick k
		if k=256 and mousex>500 {
			y=(mousey-20)/30 :if y>-1 and y<3 :break
		}
	loop
	return y
