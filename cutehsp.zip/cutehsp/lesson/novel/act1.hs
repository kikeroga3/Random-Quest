	fnm="act1.hs" :bsave "svdat",fnm

*park
	fnm="park":gosub *grp
	mes "人影はまばら。ポカポカと良い陽気。"
	mes "園内は穏やかな空気に包まれている。"
	cm(0)="見る":cm(1)="人工池に行く":cm(2)="":gosub *sel
	if stat!1 :goto *edo

*pond
	fnm="pond":gosub *grp
	mes "人工池だ。鯉も泳いでいる。"
	cm(0)="投石する":cm(1)="戻る":cm(2)="":gosub *sel
	if stat=1 :goto *park

*takac
	fnm="takac":gosub *grp
	mes "「ワシは池の精・ドツボたかしさんです。あなたが落としたのは"
	mes "　スケルトンのまっきん？ それとも、花柄のまっきん？」"
	cm(0)="スケルトン":cm(1)="花柄":cm(2)="投石する":gosub *sel
	if stat=0 :goto *skel
	if stat=1 :goto *hana

	gosub *grp
	mes "「ムッキーッ！ 何で石なんか投げるんじゃ！"
	mes "　ムカツク！ ていうかムカツク！」"
	cm(0)="あ、ゴメン…":cm(1)="":cm(2)="":gosub *sel

	fnm="pond":gosub *grp
	mes "彼は去った。"
	cm(0)="辺りを見る":cm(1)="":cm(2)="":gosub *sel
	goto *pond

*skel
	gosub *grp
	mes "「スケスケじゃあ…(*^_^*)ポッ」"
	cm(0)="話す":cm(1)="":cm(2)="":gosub *sel
	goto *c_sharp

*hana
	gosub *grp
	mes "「花柄パンチー…(*^_^*)ポッ」"
	cm(0)="話す":cm(1)="":cm(2)="":gosub *sel

*c_sharp
	gosub *grp
	mes "「やっぱC#じゃのォ…時代はビジュアルドッドネットじゃけえのォ…」"
	cm(0)="話す":cm(1)="":cm(2)="":gosub *sel

	gosub *grp
	mes "「お前は、ええ奴じゃあ…ワシが神秘のパワーを授けちゃろう」"
	cm(0)="話す":cm(1)="":cm(2)="":gosub *sel
	run "act3.hs"

*edo
	fnm="edo":gosub *grp
	mes "「ヤァヤァヤァ！ また会えたねっ！」"
	cm(0)="また…？":cm(1)="":cm(2)="":gosub *sel

	gosub *grp
	mes "「あなたの幸せを祈らせてください」"
	cm(0)="祈らせる":cm(1)="なぐる":cm(2)="":gosub *sel
	if stat!1 :goto *noah

	fnm="park":gosub *grp
	mes "「ひいいっ、ひいいいっ！」"
	mes "逃げていった。何か大切なものを失ったような気がする…"
	cm(0)="辺りを見る":cm(1)="":cm(2)="":gosub *sel
	goto *park

*noah
	fnm="noah":gosub *grp
	mes "彼は祈り終えると何かを取り出し、くれた。"
	mes "「無料です。幸せのアイテムですよ」"
	cm(0)="もらっとく":cm(1)="":cm(2)="":gosub *sel

	gosub *grp
	mes "古いアナログレコードのようだ。なぜ、こんなものを…？"
	mes "「それでは、シャーラバーイ」"
	cm(0)="あ、ハイ…":cm(1)="":cm(2)="":gosub *sel

	fnm="park":gosub *grp
	mes "彼は去った。"
	cm(0)="辺りを見る":cm(1)="":cm(2)="":gosub *sel

*park2
	fnm="park":gosub *grp
	mes "すべり台やブランコ、テーブルとベンチが並び、人工池もみえる。"
	cm(0)="見る":cm(1)="人工池に行く":cm(2)="":gosub *sel
	if stat=0 :goto *edo

	fnm="pond":gosub *grp
	mes "人工池だ。鯉も泳いでいる。"
	cm(0)="CDをポイ":cm(1)="投石する":cm(2)="戻る":gosub *sel
	if stat=1 :goto *takac
	if stat=2 :goto *park2
	run "act2.hs"

*grp
	color 255,255,255:boxf 0,0,640,480
	color 0,0,0
	pos 10,10:picload fnm+".png"
	pos 10,320
	return

*sel
	pos 500,20
	repeat 3:mes cm(cnt):loop
	repeat
		wait 10 :stick k
		if k=256 and mousex>500 {
			y=(mousey-20)/30 :if y>-1 and y<3 :break
		}
	loop
	return y
