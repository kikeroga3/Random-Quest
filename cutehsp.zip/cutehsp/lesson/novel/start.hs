	font "tiny.ttf",30

	fnm="gate":gosub *grp
	mes "～ 新宿(にいじゅく)パーク鬼神伝説 ～"
	cm(0)="最初から":cm(1)="続きから":cm(2)="":gosub *sel
	if stat=1 {
		bload "svdat",fnm :run fnm
	}

*gate
	fnm="gate":gosub *grp
	mes "とてつもなくヒマだったので新宿公園まで散歩にきた。"
	cm(0)="園内に入る":cm(1)="遊歩道に行く":cm(2)="":gosub *sel
	if stat=0 :goto *yasu

*side
	fnm="sidewalk":gosub *grp
	mes "もう一つの入口だ。ここからも公園に入ることができる。"
	cm(0)="園内に入る":cm(1)="見る":cm(2)="戻る":gosub *sel
	if stat=2 :goto *gate
	if stat=0 :run "act1.hs"

	fnm="ggg":gosub *grp
	mes "「オレはGGG！ 男なら戦え！ グズグズするなよ！」"
	cm(0)="話す":cm(1)="無視する":cm(2)="":gosub *sel
	if stat=1 :goto *side

	gosub *grp
	mes "「胸のエンジンに火をつけるんだ！」"
	cm(0)="話す":cm(1)="無視する":cm(2)="":gosub *sel
	if stat=1 :goto *side

	gosub *grp
	mes "「若さとは振り向かないことなのさ！」"
	cm(0)="話す":cm(1)="無視する":cm(2)="":gosub *sel
	if stat=1 :goto *side

	gosub *grp
	mes "「愛とは、ためらわないことさ！」"
	cm(0)="話す":cm(1)="無視する":cm(2)="":gosub *sel
	if stat=1 :goto *side

	gosub *grp
	mes "「じゃあな、元気でやれよ！」"
	cm(0)="ど、どうも…":cm(1)="":cm(2)="":gosub *sel
	goto *side

*yasu
	fnm="yasu":gosub *grp
	mes "「ぬふウゥ～ 中に入りたくば この俺を倒してからにしてもらおう」"
	cm(0)="戦う":cm(1)="逃げる":cm(2)="":gosub *sel
	if stat!0 :goto *side

	fnm="pika":gosub *grp
	mes "「貧弱ッ！貧弱ゥッ！！」"
	mes "安木の超パワー『銀河ギリギリやっぱりお前がNo.1だ！』がさく裂！"
	mes "君は失神昏倒！"
	mes ""
	mes "GAME OVER"
	stop

*grp
	color 255,255,255:boxf 0,0,640,480
	color 0,0,0
	pos 10,10:picload fnm+".png"
	pos 10,320
	return

*sel
	pos 500,20
	repeat 3:mes cm(cnt):loop
	repeat
		wait 10 :stick k
		if k=256 and mousex>500 {
			y=(mousey-20)/30 :if y>-1 and y<3 :break
		}
	loop
	return y
