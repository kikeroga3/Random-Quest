title "6*4="+(6*4)
stop
