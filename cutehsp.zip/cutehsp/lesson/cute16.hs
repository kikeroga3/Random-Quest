a=10
if a=10 :title "a is 10.":else:title "a is not 10"
stop
