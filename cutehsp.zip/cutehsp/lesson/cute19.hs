title "UFO appears"
repeat
    stick key
    if key=256 :gosub *ufo
    wait 10
loop

*ufo
    x=mousex:y=mousey
    color 150,250,0:boxf x-20,y-5,x+20,y+5:boxf x-8,y-10,x+8,y+10
    color 0,255,255:boxf x-2,y-2,x+2,y+2
    return
