title "Acceleration Move"

	px=320 :py=240

	repeat
		redraw 0
		color :boxf 0,0,640,480

		stick k
		if k=1 :dx=dx-(dx>-13)
		if k=4 :dx=dx+(dx<13)
		if k=2 :dy=dy-(dy>-13)
		if k=8 :dy=dy+(dy<13)

		px=px+dx :py=py+dy
		if px>639 or px<0 :dx=-dx
		if py>479 or py<0 :dy=-dy

		ch=2128969162 :gosub *dot5 :wait 5
		redraw 1
	loop
	stop

*dot5
	sz=8 :a=16777216 :c=ch/33554432
	p1=c/16 :p2=(c&12)/4 :p3=c&3
	color 80*p1+15,80*p2+15,80*p3+15
	repeat 25
		if (ch & a) {
			x=px+sz*(cnt\5)-(sz*5/2)
			y=py+sz*(cnt/5)-(sz*5/2)
			boxf x,y,x+sz,y+sz
		}
		a=a/2
	loop
	return

