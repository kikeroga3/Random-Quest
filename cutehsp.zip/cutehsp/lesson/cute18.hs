repeat
    r=rnd(3)
    if r=0 :title "Gu!"
    if r=1 :title "Choki!"
    if r=2 :title "Paa!"
    wait 100
loop
