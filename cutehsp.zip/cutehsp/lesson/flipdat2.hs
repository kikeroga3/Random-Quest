;Reversal Byte Data-2

;配列変数flに左右反転バイトデータを用意
dim fl,256
repeat 256
	p=cnt:a=0:b=1:c=128
	repeat 8
		if p&b :a=a+c
		b=b+b:c=c/2
	loop
	fl(p)=a
loop
p=1  :gosub *flip
p=128:gosub *flip
p=19 :gosub *flip
p=155:gosub *flip
p=88 :gosub *flip
stop

;反転データを参照するだけでOK
*flip
	title "Original="+p+" Reversal="+fl(p)
	wait 300
	return

