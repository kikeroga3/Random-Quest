
flg=108
s="Bit "
if flg&1   :s=s+"1 "
if flg&2   :s=s+"2 "
if flg&4   :s=s+"3 "
if flg&8   :s=s+"4 "
if flg&16  :s=s+"5 "
if flg&32  :s=s+"6 "
if flg&64  :s=s+"7 "
if flg&128 :s=s+"8 "
title s+"On!"
stop

