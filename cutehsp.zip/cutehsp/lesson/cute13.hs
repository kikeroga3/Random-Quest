x=10
repeat 5
	boxf x,10,x+30,40
	x=x+40
loop
stop
