; 疑似3D 左手座標系 カメラは原点、カメラベクトルは0,0,1（中心から奥を見る）で固定

	sdim bf,65000
	bload "d3obj.bin",bf

	; 各種初期値
	PI=3.14159265358979323846	; 円周率
	argp=PI*30.0/180.0			; 視野角（半分）をラジアンに変換
	tanp=sin(argp)/cos(argp)	; 射影変換行列用tan値
	near=10.0 :far=1000.0		; 近視距離、遠視距離
	fmn=far-near				; 遠視距離と近視距離の差
	scx=640.0 :scy=480.0		; 画面サイズXY
	schx=320.0 :schy=240.0		; 画面サイズXY（半分）

	; 3Dオブジェクトの位置
	ox=0.0 :oy=0.0 :oz=200.0

*main
	redraw 0
	color 0,0,0: boxf 0,0,640,480
	color 255,255,255
	gosub *obj_draw
	redraw 1 :wait 1
	ang = ang + 2.0
	if ang > 360.0 :ang = 0.0
	goto *main

*obj_draw
	vx = 0.3
	vy = 0.6
	vz = 0.9
	va = PI*ang/180.0	; 回転角度をラジアンに変換
	n=1 :i=0
*rep
	; 形状データ取得
	mpx=double(peek(bf,i)-128)
	mpy=double(peek(bf,i+1)-128)
	mpz=double(peek(bf,i+2)-128)

	gosub *shift_rotate

	p1=x1+ox :p2=y1+oy :p3=z1+oz
	gosub *trans3Dto2D :xx2=dx :yy2=dy

	if n>1 {
		if n=3 :return
		line xx1,yy1,xx2,yy2
	}
	n=peek(bf,i+3)
	xx1=xx2 :yy1=yy2 :i=i+4
	goto *rep

; 以下モジュール等だったもの

; 3D上の座標(p1,p2,p3)を2D上の座標(dx,dy)へ変換する
*trans3Dto2D

	; 0除算回避のため、Z値が0.0のときは1.0にする
	if(p3==0.0):p3 = 1.0

	; 座標*射影行列*ビューポート行列を一括で行う（ワールド行列とビュー行列は固定値のため省略）
	dx1 = schx*p1*scy/(scx*tanp) + p3*schx
	dy1 = -schy*p2/tanp + p3*schy
	dz1 = p3*far/fmn -(near*far)/fmn
	dw1 = p3
	dx = int(dx1 / dw1)
	dy = int(dy1 / dw1)
	return

; rotate 任意軸周りの空間回転演算 ( x0, y0, z0, vx, vy, vz, cx, cy, cz, va, x1, y1, z1)
; 入力値 mpx mpy mpz, 回転軸ベクトル vx vy vz, 回転角度 va, 出力変数 x1 y1 z1
*shift_rotate

	; 回転軸の単位ベクトル化
	r = sqrt(vx*vx + vy*vy + vz*vz)
	ax = vx/r : ay = vy/r : az = vz/r

	; 回転演算
	sin1 = sin(va)
	cos1 = cos(va)
	l_cos1 = 1.0 - cos1

	x1 = (ax*ax*l_cos1+cos1)*mpx + (ax*ay*l_cos1-az*sin1)*mpy + (az*ax*l_cos1+ay*sin1)*mpz
	y1 = (ax*ay*l_cos1+az*sin1)*mpx + (ay*ay*l_cos1+cos1)*mpy + (ay*az*l_cos1-ax*sin1)*mpz
	z1 = (az*ax*l_cos1-ay*sin1)*mpx + (ay*az*l_cos1+ax*sin1)*mpy + (az*az*l_cos1+cos1)*mpz
	return

