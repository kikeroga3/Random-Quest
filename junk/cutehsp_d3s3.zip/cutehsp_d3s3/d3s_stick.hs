; 疑似3D 左手座標系 カメラは原点、カメラベクトルは0,0,1(中心から奥を見る)で固定

	; 3Dオブジェクトの形状データ読込み
	dim ob,256
	sdim bf,1000
	bf="0,0,-50,2,-40,0,50,2,40,0,50,2,0,0,-50,2,0,20,50,2,20,0,50,2,0,0,-50,2,-20,0,50,2,0,20,50,3,"
	gosub *spl_to_num

	; 各種初期値
	PI=3.14159265358979323846		; 円周率
	argp=PI*30.0/180.0				; 視野角(半分)をラジアンに変換
	tanp=sin(argp)/cos(argp)		; 射影変換行列用tan値
	near=10.0 :far=1000.0			; 近視距離、遠視距離
	fmn=far-near					; 遠視距離と近視距離の差
	scx=640.0 :scy=480.0			; 画面サイズXY
	schx=scx/2.0 :schy=scy/2.0		; 画面サイズXY(半分)
	ang=0.0							; double型で初期化
	ox=0.0 :oy=20.0 :oz=200.0		; 3Dオブジェクトの位置

*main
	redraw 0
	color 0,0,0: boxf 0,0,640,480
	color 255,255,255
	gosub *obj_draw

	stick k
	if k=1 and ang<50.0 :ang=ang+0.5
	if k=4 and ang>-50.0 :ang=ang-0.5
	ox=ox-(ang/30.0)
	if ox<-200.0 :ox=-200.0
	if ox>200.0 :ox=200.0

	redraw 1 :wait 1
	goto *main

*obj_draw
	vx=0.0 :vy=0.0 :vz=1.0		; 回転軸ベクトル
	va=PI*ang/180.0				; 回転角度をラジアンに変換
	n=1 :i=0
*obj_rep
	mpx=double(ob(i))		; 形状データ取得
	mpy=double(ob(i+1))
	mpz=double(ob(i+2))
	gosub *xyz_rotate				; 3D座標回転計算
	p1=x1+ox :p2=y1+oy :p3=z1+oz
	gosub *trans3Dto2D :xx2=dx :yy2=dy	; 3D座標→2D座標変換
	if n=3 :return
	if n>1 :line xx1,yy1,xx2,yy2		; 描画
	n=ob(i+3)
	xx1=xx2 :yy1=yy2 :i=i+4
	goto *obj_rep

; 3D上の座標(p1,p2,p3)を2D上の座標(dx,dy)へ変換する
*trans3Dto2D

	if p3=0.0 :p3=1.0								; 0除算回避

	dx1=(schx*p1*scy+p3*schx*scx*tanp)/(scx*tanp)	; 座標*射影行列*ビューポート行列を一括で行う
	dy1=(p3*schy*tanp-schy*p2)/tanp					; (ワールド行列とビュー行列は固定値のため省略)
	dx=int(dx1/p3) :dy=int(dy1/p3)
	return

; 任意軸周りの空間回転演算(入力値 mpx mpy mpz, 回転軸ベクトル vx vy vz, 回転角度 va, 出力変数 x1 y1 z1)
*xyz_rotate

	; 回転軸の単位ベクトル化
	r=sqrt(vx*vx+vy*vy+vz*vz)
	ax=vx/r :ay=vy/r :az=vz/r

	; 回転演算
	sin1=sin(va) :cos1=cos(va)
	l_cos1=1.0-cos1
	x1=(ax*ax*l_cos1+cos1)*mpx+(ax*ay*l_cos1-az*sin1)*mpy+(az*ax*l_cos1+ay*sin1)*mpz
	y1=(ax*ay*l_cos1+az*sin1)*mpx+(ay*ay*l_cos1+cos1)*mpy+(ay*az*l_cos1-ax*sin1)*mpz
	z1=(az*ax*l_cos1-ay*sin1)*mpx+(ay*az*l_cos1+ax*sin1)*mpy+(az*az*l_cos1+cos1)*mpz
	return

; 3Dデータを配列変数に格納
*spl_to_num
	s1="String" :p1=0 :p2=0 :p3=0
*spl_rep
	a=peek(bf,p1) :if a=0 :return
	if a=44 {
		poke s1,p2,0 :p2=0 :ob(p3)=int(s1) :p3=p3+1
	} else {
		poke s1,p2,a :p2=p2+1
	}
	p1=p1+1 :goto *spl_rep

