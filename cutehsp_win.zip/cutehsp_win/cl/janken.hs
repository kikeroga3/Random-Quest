;Rock-Paper-Scissors

	s(0)="Rock"
	s(1)="Scissors"
	s(2)="Paper"

	mes "Ja-n ke-n.."

*aiko
	r=rnd(3)+1

*inp
	repeat 3
		mes "["+(1+cnt)+"] "+s(cnt)
	loop
	input a,1,2
	a=int(a)
	if a<1 or a>3 :goto *inp

	mes "Poi!"
	mes "Cmp:"+s(r-1)
	mes "You:"+s(a-1)

	if a=r {
		mes "Aiko de.."
		goto *aiko
	}
	if a=1 {
		if r=2 :mes "You Win!"
		if r=3 :mes "You Lose."
	}
	if a=2 {
		if r=3 :mes "You Win!"
		if r=1 :mes "You Lose."
	}
	if a=3 {
		if r=1 :mes "You Win!"
		if r=2 :mes "You Lose."
	}

