x=320 :y=440
repeat
    redraw 0
    color 0,0,0 :boxf 0,0,639,479
    stick key
    if key=1 {
        x=x-8
        if x<0 :x=0
    }
    if key=4 {
        x=x+8
        if x>639 :x=639
    }
    gosub *own
    redraw 1
    wait 5
loop
stop

*own
    color 0,100,250
    boxf x-16,y-5,x+16,y+10 :boxf x-6,y-15,x+6,y
    return
