	fnm="act2.hs" :bsave "svdat",fnm

	fnm="kakure":gosub *grp
	mes "「ニャー！」"
	cm(0)="見る":cm(1)="":cm(2)="":gosub *sel

	gosub *grp
	mes "彼女はずっと昔に、この池で溺れ死んだ猫の霊であった。"
	mes "今は精霊化して、この池の管理人になっているのだ！"
	cm(0)="話す":cm(1)="":cm(2)="":gosub *sel

	gosub *grp
	mes "「あなたにロトの血を分けてあげましょう。"
	mes "　一時的にロトの勇者なみに強くなれますよ」"
	cm(0)="お願いする":cm(1)="":cm(2)="":gosub *sel

*pond
	fnm="pond":gosub *grp
	mes "夢か幻か…しかし、身体に未知のパワーを感じていた。"
	cm(0)="戻る":cm(1)="":cm(2)="":gosub *sel

	fnm="park":gosub *grp
	mes "新宿公園の門番・安木。今ならヤツを倒せそうな気がするッ！"
	cm(0)="公園口へ":cm(1)="人工池に戻る":cm(2)="":gosub *sel
	if stat=1 :goto *pond

	fnm="yasu":gosub *grp
	mes "「ぬっ、どこから現われたか！？"
	mes "　この俺を倒さぬ限り、中には入れぬぞ」"
	cm(0)="気を高める":cm(1)="":cm(2)="":gosub *sel

	gosub *grp
	mes "「ほう…この気…！ 先ほどとは別人のようだ。面白い。"
	mes "　ならば、この安木！ 最大限の礼儀を以て応えてやろう」"
	cm(0)="見る":cm(1)="":cm(2)="":gosub *sel

	fnm="yasu2":gosub *grp
	mes "「ふはァ…はああァァ…！」"
	cm(0)="見る！":cm(1)="":cm(2)="":gosub *sel

	fnm="choya":gosub *grp
	mes "超安木・改"
	cm(0)="見る！？":cm(1)="":cm(2)="":gosub *sel

*choya2
	fnm="choya2":gosub *grp
	mes "超安木・改「かかってくるがよい…！」"
	cm(0)="ギラ":cm(1)="マヒャド":cm(2)="バルス":gosub *sel
	if stat=1 :goto *yasu

	gosub *grp
	mes "超安木・改「効かぬ！ 効かぬわッ！！ うわっはっはっはっ！！」"
	cm(0)="じゅもん":cm(1)="":cm(2)="":gosub *sel
	goto *choya2

*yasu
	fnm="yasu":gosub *grp
	mes "「ぬっ！ 何だッ！？ 『超安木』が解けた！？ ぬうぅ！ なぜだ！？」"
	cm(0)="ギラ":cm(1)="バルス":cm(2)="":gosub *sel

	fnm="pika":gosub *grp
	mes "「ぐわああーッ！」"
	cm(0)="トドメだーッ":cm(1)="":cm(2)="":gosub *sel

	fnm="way":gosub *grp
	mes "新宿公園の魔人・安木は倒れた。"
	mes "しかし、第2、第3の安木がいるかもしれない。"
	mes "もしかしたら、あなたのすぐそばに…"
	mes ""
	mes "GOOD END"
	stop

*grp
	color 255,255,255:boxf 0,0,640,480
	color 0,0,0
	pos 10,10:picload fnm+".png"
	pos 10,320
	return

*sel
	pos 500,20
	repeat 3:mes cm(cnt):loop
	repeat
		wait 10 :stick k
		if k=256 and mousex>500 {
			y=(mousey-20)/30 :if y>-1 and y<3 :break
		}
	loop
	return y
