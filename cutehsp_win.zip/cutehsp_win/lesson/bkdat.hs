;�w�i�f�[�^�̗p��
dim bk,900
repeat 900:bk(cnt)=2:loop
repeat 8 :c=cnt
	repeat (30-4*c)
		bk(cnt+62*c)=1:bk(870+cnt-58*c)=1
		bk(30*cnt+62*c)=1:bk(30*cnt+58*c+29)=1
	loop
loop
repeat 26
	bk(392+cnt)=2:bk(482+cnt)=2
	bk(73+30*cnt)=2:bk(76+30*cnt)=2
loop

;�w�i�f�[�^�̕\��
redraw 0
repeat 900
	x=16*(cnt\30)+80:y=16*(cnt/30)
	if bk(cnt)=1 :boxf x,y,x+15,y+15
	if bk(cnt)=2 :boxf x+6,y+6,x+10,y+10
loop
redraw 1
stop
