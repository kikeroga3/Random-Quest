color 255,0,0
pset 10,10
color 0,255,0
line 120,80,500,400
color 0,0,255
boxf 200,100,250,200
stop
