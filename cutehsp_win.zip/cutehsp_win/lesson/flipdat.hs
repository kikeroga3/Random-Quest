;Reversal Byte Data

p=19:gosub *flip
title "Original="+p+" Reversal="+stat
stop

*flip
a=0:b=1:c=128
repeat 8
	if p&b :a=a+c
	b=b+b:c=c/2
loop
return a

