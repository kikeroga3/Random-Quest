x=320 :y=440
repeat
    stick key
    if key=1 :x=x-8
    if key=4 :x=x+8
    gosub *own
    wait 5
loop
stop

*own
    color 0,100,250
    boxf x-16,y-5,x+16,y+10 :boxf x-6,y-15,x+6,y
    return
