title "Jump Action"

	px=320 :py=450 :dy=0

	repeat
		redraw 0
		color :boxf 0,0,640,480

		stick k
		if k=1 {
			px=px-10:if px<20 :px=20
		}
		if k=4 {
			px=px+10:if px>620 :px=620
		}
		if (k&5)>0 and py=450 :dy=-50
		py=py+dy :dy=dy+5
		if py>450 :py=450 :dy=0

		ch=2128969162 :gosub *dot5 :wait 5
		redraw 1
	loop
	stop

*dot5
	sz=8 :a=16777216 :c=ch/33554432
	p1=c/16 :p2=(c&12)/4 :p3=c&3
	color 80*p1+15,80*p2+15,80*p3+15
	repeat 25
		if (ch & a) {
			x=px+sz*(cnt\5)-(sz*5/2)
			y=py+sz*(cnt/5)-(sz*5/2)
			boxf x,y,x+sz,y+sz
		}
		a=a/2
	loop
	return

