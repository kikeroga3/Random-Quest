c=5
a(0)=15
a(1)=80
a(2)=43
a(3)=12
a(4)=38
title "Five values="+a(0)+" "+a(1)+" "+a(2)+" "+a(3)+" "+a(4)
wait 500
h=0
repeat c
	h=h+a(cnt)
loop
title "Average="+(h/c)
stop
