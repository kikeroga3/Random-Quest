title "Calc 3^ Result="+(3*3*3+3*3+3)
stop
