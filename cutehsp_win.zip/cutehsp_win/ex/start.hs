title "CuteHSP Extra"
font "tiny.ttf",48
pos 20,10:picload "tamarin.jpg"
pos 200,100:picload "cutehsp.png"
pos 80,360:mes "Hello, World!?"
mes "文字と画像を表示します。"
redraw 1
stop
