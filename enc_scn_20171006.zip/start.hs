
	sdim fnm,64 :sdim msg,8000 :sdim bf,256000
	dim sel,16 :sl=0
	dim flg,256

	fnm="open.scn"
*restat
	gosub *decod
	po_ret=0 :po_sav=po

*main
	tok=peek(bf,po)

	if tok>9 {
		;文章の表示
		repeat
			a=peek(bf,po)
			if a<10 :a=0 :po=po-1
			poke msg,cnt,a :po=po+1
			if a=0 :break
		loop
		mes msg
	} else {
		;各コードの処理
		if tok=1 :end
		if tok=2 :gosub *c_inp
		if tok=3 :po=po_ret
		if tok=4 {
			sel(sl)=peek(bf,po+1) :sl=sl+1
			po=po+2
		}
		if tok=5 {
			po_ret=po+2 :lbn=peek(bf,po+1)
			:gosub *lb_srch
		}
		if tok=6 :a=peek(bf,po+1)-1 :flg(a)=peek(bf,po+2)-1 :po=po+3
		if tok=7 {
			a=peek(bf,po+1)-1 :v=peek(bf,po+2)-1 :lbn=peek(bf,po+3) :po=po+4
			if flg(a)=v :gosub *lb_srch
		}
		if tok=8 :p1=po+1 :gosub *getstr :fnm=refstr :goto *restat
		if tok=9 :po=po+2

	}

	goto *main






;Sub Functions

*decod
	bload fnm,bf :sz=strsize
;	repeat sz
;		a=peek(bf,cnt) :poke bf,cnt,255-a
;	loop
	po=0 :return

;文字列を数値に変換
*strval
	p1=0
	repeat 8
		a=peek(s1,cnt)-48 :if a<0 :break
		p1=p1*10+a
	loop
	return p1

;指定位置から改行または終端までの文字列を取り出す
*getstr
	sdim s1,256
	repeat 256
		a=peek(bf,p1+cnt)
;		if a=10 or a=13 :a=0
		if a=10 or a=13 or a=32 or a=44 :a=0
		poke s1,cnt,a
		if a=0 :p2=cnt :break
	loop
	return s1

*c_inp
	input s,2,2
	if s="q" or s="Q" :mes "Quit." :end
;	if s="s" or s="S" :mes "Save." :goto *c_inp
;	if s="l" or s="L" :mes "Load." :goto *c_inp
	if sl=0 :po=po+1 :return
	s1=s :gosub *strval :a=stat
	if a>sl or a<1 :goto *c_inp
	mes "po="+po
	lbn=sel(a-1) :gosub *lb_srch
	mes "lbn="+lbn+" po="+po
	sl=0 :return

*lb_srch

	i=0
	repeat sz
		p1=peek(bf,i) :p2=peek(bf,i+1)
		if p1=9 and p2=lbn :po=i+2 :break
		if p1>9 :i=i+1
		if p1=1 :i=i+1
		if p1=2 :i=i+1
		if p1=3 :i=i+1
		if p1=4 :i=i+2
		if p1=5 :i=i+2
		if p1=6 :i=i+3
		if p1=7 :i=i+4
		if p1=8 :i=i+1
		if p1=9 :i=i+2
		if i>sz :break
	loop
	return
